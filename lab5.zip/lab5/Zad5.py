from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

im = Image.open('obraz.png')
obraz = im.copy()
obraz1 = im.copy()
obraz2= im.copy()

T = np.array(obraz, dtype='uint8')
T += 100
obraz_wynik = Image.fromarray(T, "RGB")
# obraz_wynik.show()

# obraz1.point(lambda i: i + 100).show()


def test(img, value):
    tmp = np.array(obraz2, dtype='uint8')
    for i in range(0, img.size[0]):
        for j in range(0, img.size[1]):
            p = tmp[i, j]
            # print(p)
            print([p[0] + 100, p[1] + 100, p[2] + 100, p[4]])
            # tmp[i, j] = (p[0] + 100, p[1] + 100, p[2] + 100, p[4])
    return Image.fromarray(tmp, "RGB")


test(obraz2, 100).show()

# nie działa