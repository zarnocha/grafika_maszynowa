from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


def contrast(img, contrast_factor):
    if contrast_factor < 0 or 100 < contrast_factor:
        raise ValueError('Zły wpsólczynnik')
    else:
        mn = ((255 + contrast_factor) / 255) ** 2
        return img.point(lambda i: 128 + (i - 128) * mn)


def logarithmic_transformation(img):
    return img.point(lambda i: 255 * np.log(1 + i / 255))


def gamma_transformation(img, gamma):
    if gamma < 0:
        raise ValueError('Gamma mniejsza niż 0')
    return img.point(lambda i: (i / 255) ** (1 / gamma) * 255)


img = Image.open('obraz.png')
img_copy = img.copy()

plt.subplot(3, 2, 1)
plt.imshow(contrast(img_copy, 0))
plt.title('Contrast 0')
plt.axis('off')
plt.subplot(3, 2, 2)
plt.imshow(contrast(img_copy, 25))
plt.title('Contrast 25')
plt.axis('off')
plt.subplot(3, 2, 3)
plt.imshow(contrast(img_copy, 50))
plt.title('Contrast 50')
plt.axis('off')
plt.subplot(3, 2, 4)
plt.imshow(contrast(img_copy, 75))
plt.title('Contrast 75')
plt.axis('off')
plt.subplot(3, 2, 5)
plt.imshow(contrast(img_copy, 100))
plt.title('Contrast 100')
plt.axis('off')
plt.subplots_adjust(wspace=0.5, hspace=0.5)

# logarithmic_transformation(img_copy).show()

plt.figure(facecolor='black')
plt.subplot(3, 2, 1)
plt.imshow(gamma_transformation(img_copy, 10))
plt.title('Gamma 10', color='white')
plt.axis('off')
plt.subplot(3, 2, 2)
plt.imshow(gamma_transformation(img_copy, 20))
plt.title('Gamma 20', color='white')
plt.axis('off')
plt.subplot(3, 2, 3)
plt.imshow(gamma_transformation(img_copy, 30))
plt.title('Gamma 30', color='white')
plt.axis('off')
plt.subplot(3, 2, 4)
plt.imshow(gamma_transformation(img_copy, 40))
plt.title('Gamma 40', color='white')
plt.axis('off')
plt.subplot(3, 2, 5)
plt.imshow(gamma_transformation(img_copy, 50))
plt.title('Gamma 50', color='white')
plt.axis('off')
plt.subplots_adjust(wspace=0.5, hspace=0.5)
# plt.show()
