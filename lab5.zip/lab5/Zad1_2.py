from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


def paste_initials(img, initials, m, n, color):
    for i in range(0, initials.size[0]):
        for j in range(0, initials.size[1]):
            if m + i < img.size[0] and n + j < img.size[1]:
                if initials.getpixel((i, j)) == 0:
                    img.putpixel((m + i, n + j), color)
            else:
                if initials.getpixel((i, j)) == 0:
                    img.putpixel((m + i - img.size[0], (n + j) - img.size[1]), color)


def paste_initials_mask(img, initials, m, n, x, y, z):
    for i in range(0, initials.size[0]):
        for j in range(0, initials.size[1]):
            if initials.getpixel((i, j)) == 0:
                if m + i < img.size[0] and n + j < img.size[1]:
                    pixel = img.getpixel((i + m, j + n))
                    img.putpixel((i + m, j + n), (pixel[0] + x, pixel[1] + y, pixel[2] + z))
                else:
                    pixel = img.getpixel((i + (m - img.size[0]), j + (n - img.size[1])))
                    img.putpixel((i + (m - img.size[0]), j + (n - img.size[1])), (pixel[0] + x, pixel[1] + y, pixel[2] + z))


img = Image.open('obraz.png')
img_copy = img.copy()
img_copy2 = img.copy()
initials = Image.open('inicjaly.bmp')

initials_corner_pos = (img_copy.size[0] - initials.size[0], img_copy.size[1] - initials.size[1])
paste_initials(img_copy, initials, initials_corner_pos[0], initials_corner_pos[1], (255, 0, 0))
img_copy.save('obraz1.png')

initials_middle_pos = (int(img_copy2.size[0]/2) - int(initials.size[0]/2), int(img_copy2.size[1]/2) - int(initials.size[1]/2))
paste_initials_mask(img_copy2, initials, initials_middle_pos[0], initials_middle_pos[1], 50, 50, 50)
img_copy2.save('obraz2.png')
