from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


def load_pase_initials(img, initials, m, n, color):
    img_t = img.load()
    initials_t = initials.load()
    for i in range(0, initials.size[0]):
        for j in range(0, initials.size[1]):
            if m + i < img.size[0] and n + j < img.size[1]:
                if initials_t[i, j] == 0:
                    img_t[m + i, n + j] = color
            else:
                if initials_t[i, j] == 0:
                    img_t[m + (i - img.size[0]), n + (j - img.size[1])] = color


def load_pase_initials_mask(img, initials, m, n, x, y, z):
    img_t = img.load()
    initials_t = initials.load()
    for i in range(0, initials.size[0]):
        for j in range(0, initials.size[1]):
            if initials_t[i, j] == 0:
                if m + i < img.size[0] and n + j < img.size[1]:
                    pixel = img_t[i + m, j + n]
                    img_t[i + m, j + n] = (pixel[0] + x, pixel[1] + y, pixel[2] + z)
                else:
                    pixel = img_t[i + (m - img.size[0]), j + (n - img.size[1])]
                    img_t[i + (m - img.size[0]), j + (n - img.size[1])] = (pixel[0] + x, pixel[1] + y, pixel[2] + z)


img = Image.open('obraz.png')
img_copy = img.copy()
img_copy2 = img.copy()
initials = Image.open('inicjaly.bmp')

load_pase_initials(img_copy, initials, 500, 500, (255, 0, 0))
# img_copy.show()
load_pase_initials_mask(img_copy2, initials, 500, 500, 50, 50, 50)
# img_copy2.show()
